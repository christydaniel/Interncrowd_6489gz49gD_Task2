<?php
    error_reporting(0);
 		 ob_start();
    session_start();
 
 	header("Content-Type: text/html;charset=UTF-8");
	
	
	if($_SERVER['HTTP_HOST']=="localhost" or $_SERVER['HTTP_HOST']=="192.168.1.125")
	{	
		//local  
		DEFINE ('DB_USER', 'root');
		DEFINE ('DB_PASSWORD', '');
		DEFINE ('DB_HOST', 'localhost');
		DEFINE ('DB_NAME', 'friendvilla_app');
	}
	else
	{
		//local live 
		DEFINE ('DB_USER', 'friendvilla_main');
		DEFINE ('DB_PASSWORD', '[5v-GP9xQO{Z');
		DEFINE ('DB_HOST', 'localhost');
		DEFINE ('DB_NAME', 'friendvilla_main');
	}

	
	$mysqli =mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);

	if ($mysqli->connect_errno) 
	{
    	echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
	}

	mysqli_query($mysqli,"SET NAMES 'utf8'");
    
?> 
	 
 